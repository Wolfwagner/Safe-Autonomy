
"use strict";

let Gpgga = require('./Gpgga.js');
let Time = require('./Time.js');
let Gpgsa = require('./Gpgsa.js');
let Inspva = require('./Inspva.js');
let NovatelHeading2 = require('./NovatelHeading2.js');
let Gphdt = require('./Gphdt.js');
let NovatelReceiverStatus = require('./NovatelReceiverStatus.js');
let Inspvax = require('./Inspvax.js');
let NovatelMessageHeader = require('./NovatelMessageHeader.js');
let Range = require('./Range.js');
let TrackstatChannel = require('./TrackstatChannel.js');
let NovatelCorrectedImuData = require('./NovatelCorrectedImuData.js');
let Trackstat = require('./Trackstat.js');
let NovatelPosition = require('./NovatelPosition.js');
let RangeInformation = require('./RangeInformation.js');
let Insstdev = require('./Insstdev.js');
let NovatelSignalMask = require('./NovatelSignalMask.js');
let Inscov = require('./Inscov.js');
let Satellite = require('./Satellite.js');
let ClockSteering = require('./ClockSteering.js');
let NovatelDualAntennaHeading = require('./NovatelDualAntennaHeading.js');
let NovatelUtmPosition = require('./NovatelUtmPosition.js');
let Gprmc = require('./Gprmc.js');
let NovatelXYZ = require('./NovatelXYZ.js');
let NovatelExtendedSolutionStatus = require('./NovatelExtendedSolutionStatus.js');
let Gpgsv = require('./Gpgsv.js');
let NovatelVelocity = require('./NovatelVelocity.js');

module.exports = {
  Gpgga: Gpgga,
  Time: Time,
  Gpgsa: Gpgsa,
  Inspva: Inspva,
  NovatelHeading2: NovatelHeading2,
  Gphdt: Gphdt,
  NovatelReceiverStatus: NovatelReceiverStatus,
  Inspvax: Inspvax,
  NovatelMessageHeader: NovatelMessageHeader,
  Range: Range,
  TrackstatChannel: TrackstatChannel,
  NovatelCorrectedImuData: NovatelCorrectedImuData,
  Trackstat: Trackstat,
  NovatelPosition: NovatelPosition,
  RangeInformation: RangeInformation,
  Insstdev: Insstdev,
  NovatelSignalMask: NovatelSignalMask,
  Inscov: Inscov,
  Satellite: Satellite,
  ClockSteering: ClockSteering,
  NovatelDualAntennaHeading: NovatelDualAntennaHeading,
  NovatelUtmPosition: NovatelUtmPosition,
  Gprmc: Gprmc,
  NovatelXYZ: NovatelXYZ,
  NovatelExtendedSolutionStatus: NovatelExtendedSolutionStatus,
  Gpgsv: Gpgsv,
  NovatelVelocity: NovatelVelocity,
};
