
"use strict";

let NovatelFRESET = require('./NovatelFRESET.js')

module.exports = {
  NovatelFRESET: NovatelFRESET,
};
